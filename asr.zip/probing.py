import torch
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from transformers import WhisperForConditionalGeneration, WhisperProcessor
from datasets import load_dataset, Audio
from tqdm import tqdm
import logging

# ========== 配置 ==========
MODEL_NAME = "openai/whisper-medium"
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
LANGUAGES = ['french', 'japanese', 'russian', 'turkish', 'mandarin', 'afrikaans']
SAMPLES_PER_LANG = 300  # 每种语言300个样本
MAX_AUDIO_LENGTH = 30  # 最大音频长度（秒）

# ========== 加载模型 ==========
print("加载模型和处理器...")
processor = WhisperProcessor.from_pretrained(MODEL_NAME)
model = WhisperForConditionalGeneration.from_pretrained(MODEL_NAME).to(DEVICE).eval()

# ========== 注册 Hook 捕获中间表示 ==========
encoder_activations = {}

def register_hooks():
    """注册钩子捕获encoder各层输出"""
    hooks = []
    
    # 捕获卷积层输出
    def conv_hook(module, input, output):
        encoder_activations["conv_output"] = output.detach().cpu()
    hooks.append(model.model.encoder.conv1.register_forward_hook(conv_hook))
    hooks.append(model.model.encoder.conv2.register_forward_hook(conv_hook))
    
    # 捕获位置编码
    def pos_emb_hook(module, input, output):
        encoder_activations["pos_embeddings"] = output.detach().cpu()
    hooks.append(model.model.encoder.embed_positions.register_forward_hook(pos_emb_hook))
    
    # 捕获各transformer层
    for i, layer in enumerate(model.model.encoder.layers):
        def layer_hook(module, input, output, idx=i):
            encoder_activations[f"layer_{idx}"] = output[0].detach().cpu()
        hooks.append(layer.register_forward_hook(layer_hook))
    
    # 捕获最终输出
    def final_hook(module, input, output):
        encoder_activations["encoder_output"] = output[0].detach().cpu()
    hooks.append(model.model.encoder.register_forward_hook(final_hook))
    
    return hooks

# ========== 数据加载函数 ==========
def load_language_data(lang, sample_count=SAMPLES_PER_LANG):
    """加载指定语言的样本数据"""
    print(f"加载 {lang} 数据...")
    
    # 获取语言代码（Common Voice 格式）
    lang_code = {
        'french': 'fr',
        'japanese': 'ja',
        'russian': 'ru',
        'turkish': 'tr',
        'mandarin': 'zh-CN',
        'afrikaans': 'af'
    }[lang]
    
    try:
        # 加载数据集
        ds = load_dataset("common_voice", lang_code, split="validation", streaming=True)
        samples = []
        
        # 流式加载样本
        for sample in tqdm(ds.take(sample_count), desc=f"处理 {lang}", total=sample_count):
            # 检查音频长度
            audio_length = len(sample["audio"]["array"]) / sample["audio"]["sampling_rate"]
            if audio_length > MAX_AUDIO_LENGTH:
                continue
                
            # 处理音频
            input_features = processor(
                sample["audio"]["array"],
                sampling_rate=sample["audio"]["sampling_rate"],
                return_tensors="pt"
            ).input_features.to(DEVICE)
            
            samples.append({
                "input_features": input_features,
                "language": lang
            })
        
        return samples
    except Exception as e:
        logging.error(f"加载 {lang} 数据失败: {str(e)}")
        return []

# ========== 提取表示函数 ==========
def extract_representations(samples, lang):
    """提取样本的中间表示"""
    print(f"为 {lang} 提取表示...")
    
    lang_representations = {
        "conv_output": [],
        "pos_embeddings": [],
        "encoder_output": []
    }
    
    # 为各层初始化存储
    for i in range(len(model.model.encoder.layers)):
        lang_representations[f"layer_{i}"] = []
    
    # 处理每个样本
    for sample in tqdm(samples, desc=f"处理 {lang} 样本"):
        # 清空前一次激活
        encoder_activations.clear()
        
        # 前向传播（仅通过encoder）
        with torch.no_grad():
            model.model.encoder(sample["input_features"])
        
        # 存储各层表示
        for key in encoder_activations:
            # 平均时间步长
            layer_repr = encoder_activations[key].mean(dim=1).squeeze().numpy()
            lang_representations[key].append(layer_repr)
    
    # 转换为numpy数组
    for key in lang_representations:
        lang_representations[key] = np.array(lang_representations[key])
    
    return lang_representations

# ========== 数据加载与处理 ==========
# 注册钩子
hooks = register_hooks()

# 加载所有语言数据
all_representations = {}
for lang in LANGUAGES:
    samples = load_language_data(lang)
    if samples:
        all_representations[lang] = extract_representations(samples, lang)

# 移除钩子
for hook in hooks:
    hook.remove()

# ========== Probing 分类器 ==========
def train_probing_classifier(layer_name):
    """训练并评估指定层的probing分类器"""
    print(f"\n训练 {layer_name} 的probing分类器...")
    
    X = []
    y = []
    lang_to_idx = {lang: idx for idx, lang in enumerate(LANGUAGES)}
    
    # 准备数据
    for lang in LANGUAGES:
        if lang not in all_representations or layer_name not in all_representations[lang]:
            continue
            
        representations = all_representations[lang][layer_name]
        X.append(representations)
        y.extend([lang_to_idx[lang]] * len(representations))
    
    if not X:
        print(f"层 {layer_name} 无可用数据")
        return 0.0
    
    X = np.vstack(X)
    y = np.array(y)
    
    # 分割数据集
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    # 训练分类器
    clf = LogisticRegression(max_iter=1000, multi_class='multinomial', solver='lbfgs')
    clf.fit(X_train, y_train)
    
    # 评估
    y_pred = clf.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    
    print(f"{layer_name} 的语言分类准确率: {accuracy:.4f}")
    return accuracy

# ========== 表示可视化 ==========
def visualize_representations(layer_name):
    """可视化指定层的表示"""
    print(f"可视化 {layer_name} 的表示...")
    
    all_repr = []
    labels = []
    
    # 收集所有语言的表示
    for lang in LANGUAGES:
        if lang in all_representations and layer_name in all_representations[lang]:
            reprs = all_representations[lang][layer_name]
            all_repr.append(reprs)
            labels.extend([lang] * len(reprs))
    
    if not all_repr:
        print(f"层 {layer_name} 无可用数据")
        return
    
    X = np.vstack(all_repr)
    
    # PCA降维
    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(X)
    
    # t-SNE降维
    tsne = TSNE(n_components=2, perplexity=30, random_state=42)
    X_tsne = tsne.fit_transform(X)
    
    # 创建可视化
    fig, axs = plt.subplots(1, 2, figsize=(20, 8))
    
    # PCA可视化
    for lang in LANGUAGES:
        indices = [i for i, l in enumerate(labels) if l == lang]
        axs[0].scatter(X_pca[indices, 0], X_pca[indices, 1], label=lang, alpha=0.6)
    axs[0].set_title(f"{layer_name} - PCA")
    axs[0].legend()
    
    # t-SNE可视化
    for lang in LANGUAGES:
        indices = [i for i, l in enumerate(labels) if l == lang]
        axs[1].scatter(X_tsne[indices, 0], X_tsne[indices, 1], label=lang, alpha=0.6)
    axs[1].set_title(f"{layer_name} - t-SNE")
    axs[1].legend()
    
    plt.tight_layout()
    plt.savefig(f"{layer_name}_visualization.png")
    plt.show()

# ========== 分析流程 ==========
if __name__ == "__main__":
    # 1. 分析各层的语言分类能力
    layer_accuracies = {}
    layers_to_analyze = ["conv_output", "pos_embeddings", "encoder_output"] + \
                        [f"layer_{i}" for i in range(len(model.model.encoder.layers))]
    
    for layer in layers_to_analyze:
        acc = train_probing_classifier(layer)
        layer_accuracies[layer] = acc
    
    # 绘制准确率曲线（按网络深度排序）
    ordered_layers = ["conv_output", "pos_embeddings"] + \
                    [f"layer_{i}" for i in range(len(model.model.encoder.layers))] + \
                    ["encoder_output"]
    
    acc_values = [layer_accuracies[layer] for layer in ordered_layers if layer in layer_accuracies]
    
    plt.figure(figsize=(14, 6))
    plt.plot(acc_values, 'o-')
    plt.xticks(range(len(acc_values)), ordered_layers, rotation=45)
    plt.xlabel("Encoder Layer")
    plt.ylabel("Language Identification Accuracy")
    plt.title("Probing Accuracy by Encoder Layer")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("probing_accuracy_by_layer.png")
    plt.show()
    
    # 2. 可视化关键层的表示
    key_layers = ["conv_output", "layer_0", "layer_10", "encoder_output"]
    for layer in key_layers:
        visualize_representations(layer)
    
    # 3. 分析表示相似性
    print("\n分析表示相似性...")
    similarity_results = {}
    
    for lang1 in LANGUAGES:
        for lang2 in LANGUAGES:
            if lang1 == lang2 or "encoder_output" not in all_representations[lang1]:
                continue
                
            # 计算余弦相似性
            repr1 = all_representations[lang1]["encoder_output"]
            repr2 = all_representations[lang2]["encoder_output"]
            
            # 计算平均表示
            avg_repr1 = repr1.mean(axis=0)
            avg_repr2 = repr2.mean(axis=0)
            
            # 计算余弦相似度
            cos_sim = np.dot(avg_repr1, avg_repr2) / (np.linalg.norm(avg_repr1) * np.linalg.norm(avg_repr2))
            similarity_results[(lang1, lang2)] = cos_sim
    
    # 打印结果
    print("\n跨语言表示相似性 (encoder_output):")
    for (lang1, lang2), sim in similarity_results.items():
        print(f"{lang1}-{lang2}: {sim:.4f}")
    
    print("\n分析完成!")