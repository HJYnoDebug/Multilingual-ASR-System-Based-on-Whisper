import os
import torch
import random
import numpy as np
import pandas as pd
import evaluate
from datasets import Dataset, Audio
from transformers import WhisperForConditionalGeneration, WhisperProcessor, WhisperTokenizer
from torch.utils.data import DataLoader
import logging
import warnings

# ========== 设置 & 路径 ==========
print("===== 初始化设置 =====")
CHECKPOINT_PATHS = [
    "whisper_partial_finetune_all3/best.pt",
    "whisper_partial_finetune_denl/best.pt",
    "whisper_partial_finetune_ende/best.pt",
    "whisper_partial_finetune_ennl/best.pt"
]
MODEL_NAME = "openai/whisper-medium"
DEVICE     = "cuda" if torch.cuda.is_available() else "cpu"
BATCH_SIZE = 16
SEED       = 42
print(f"设备: {DEVICE}, 批大小: {BATCH_SIZE}, 随机种子: {SEED}")
print(f"待评估模型: {len(CHECKPOINT_PATHS)} 个")

# ========== 随机种子 ==========
print("设置随机种子...")
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)

# ========== 忽略警告 ==========
warnings.filterwarnings("ignore", category=UserWarning)

# ========== 加载 Processor & Tokenizer ==========
print("加载 Whisper Processor 和 Tokenizer...")
processor = WhisperProcessor.from_pretrained(MODEL_NAME, task="transcribe")
tokenizer = WhisperTokenizer.from_pretrained(MODEL_NAME, task="transcribe")
print(f"Processor 和 Tokenizer 加载完成")

# ========== 时域增强函数 ==========
def time_shift(waveform, sr, max_shift_sec=0.1):
    """在 [-max_shift_sec, +max_shift_sec] 范围内做随机循环平移"""
    max_shift = int(sr * max_shift_sec)
    shift = random.randint(-max_shift, max_shift)
    return np.roll(waveform, shift)

# ========== 自定义 Dataset Class & Collator ==========
class DynamicWhisperDataset(torch.utils.data.Dataset):
    def __init__(self, ds, processor, tokenizer, augment=False):
        self.ds = ds
        self.processor = processor
        self.tokenizer = tokenizer
        self.augment = augment

    def __len__(self):
        return len(self.ds)

    def __getitem__(self, i):
        item = self.ds[i]
        audio = item["audio_path"]["array"]
        sr    = item["audio_path"]["sampling_rate"]
        # 如开启增强，则先做时域增强
        if self.augment:
            audio = time_shift(audio, sr)

        feats = self.processor(audio, sampling_rate=sr, return_tensors="pt").input_features[0]

        # 构造 labels
        lang_tok = self.tokenizer.convert_tokens_to_ids(f"<|{item['language_name']}|>")
        label_ids = self.tokenizer(
            item["sentence"],
            return_tensors="pt",
            add_special_tokens=False
        ).input_ids[0]

        prefix = [
            self.tokenizer.convert_tokens_to_ids("<|startoftranscript|>"),
            lang_tok,
            self.tokenizer.convert_tokens_to_ids("<|transcribe|>"),
            self.tokenizer.convert_tokens_to_ids("<|notimestamps|>")
        ]
        labels = torch.tensor(prefix + label_ids.tolist() + [self.tokenizer.eos_token_id])
        return {
            "input_features": feats,
            "attention_mask": torch.ones(feats.shape[-1]),
            "labels": labels,
            "language_name": item["language_name"]
        }

class WhisperDataCollator:
    def __init__(self, tok):
        self.tok = tok

    def __call__(self, batch):
        feats = torch.stack([x["input_features"] for x in batch])
        am    = torch.stack([x["attention_mask"]   for x in batch])
        labs  = [x["labels"]                       for x in batch]
        langs = [x["language_name"]                for x in batch]

        max_len = max(l.size(0) for l in labs)
        pad_tokens = torch.full((len(batch), max_len), self.tok.pad_token_id)
        dec_mask   = torch.zeros((len(batch), max_len), dtype=torch.long)

        for i, l in enumerate(labs):
            pad_tokens[i, :l.size(0)] = l
            dec_mask[i, :l.size(0)]   = 1
        pad_tokens[pad_tokens == self.tok.pad_token_id] = -100

        return {
            "input_features": feats,
            "attention_mask": am,
            "labels": pad_tokens,
            "decoder_attention_mask": dec_mask,
            "language_name": langs
        }

collator = WhisperDataCollator(tokenizer)

# ========== Zero‑Shot 数据集准备 ==========
print("\n===== 准备 Zero-Shot 数据集 =====")
zero_langs = ['af','fr','ja','ru','tr','zh-CN']
ZERO_MAP = {
    'fr': 'french', 'fy-NL': 'frisian', 'ja': 'japanese',
    'ru': 'russian', 'tr': 'turkish', 'zh-CN': 'mandarin',
    'af': 'afrikaans',
}
zero_datasets = {}
for zl in zero_langs:
    print(f"处理语言: {zl}...")
    tsv_path = os.path.join('data/zero_shot', zl, 'validated.tsv')
    clips_dir = os.path.join('data/zero_shot', zl, 'clips')
    
    if not os.path.exists(tsv_path):
        logging.warning(f"Zero‑shot 缺失 {tsv_path}, 跳过")
        continue
    
    df = pd.read_csv(tsv_path, sep='\t')
    df = df[df['sentence'].notnull() & df['path'].notnull()]
    df['audio_path']    = df['path'].apply(lambda p: os.path.join(clips_dir, p))
    df = df[df['audio_path'].apply(os.path.exists)]
    df['language_name'] = ZERO_MAP[zl]
    
    ds = Dataset.from_pandas(df[['audio_path','sentence','language_name']])
    ds = ds.cast_column("audio_path", Audio(sampling_rate=16000))
    zero_datasets[ZERO_MAP[zl]] = ds
    print(f"  {zl} -> {ZERO_MAP[zl]}: {len(ds)} 个样本")

# 为每种语言创建两个 loader：原始 & 增强
print("\n创建 DataLoader...")
zero_loaders = {}
zero_loaders_aug = {}
for lang, ds in zero_datasets.items():
    print(f"语言: {lang} - 原始数据")
    zero_loaders[lang]     = DataLoader(
        DynamicWhisperDataset(ds, processor, tokenizer, augment=False),
        batch_size=BATCH_SIZE, shuffle=False, collate_fn=collator
    )
    print(f"语言: {lang} - 增强数据")
    zero_loaders_aug[lang] = DataLoader(
        DynamicWhisperDataset(ds, processor, tokenizer, augment=True),
        batch_size=BATCH_SIZE, shuffle=False, collate_fn=collator
    )

# ========== 评估函数 ==========
def eval_loader(loader, lang, augment):
    print(f"\n开始评估: {'增强' if augment else '原始'} {lang} 数据")
    wer_metric = evaluate.load("wer")
    cer_metric = evaluate.load("cer")
    preds, refs = [], []
    
    total_batches = len(loader)
    with torch.no_grad():
        for batch_idx, b in enumerate(loader):
            # 显示进度
            if (batch_idx + 1) % 5 == 0 or (batch_idx + 1) == total_batches:
                print(f"  处理批次: {batch_idx+1}/{total_batches}")
            
            feats = b["input_features"].to(DEVICE)
            amask = b.get("attention_mask", None)
            gen_kwargs = {
                "input_features": feats,
                "max_length": 448,
                "num_beams": 1,
                "forced_decoder_ids": [
                    processor.get_decoder_prompt_ids(language=lang, task="transcribe")
                    for lang in b["language_name"]
                ]
            }
            if amask is not None:
                gen_kwargs["attention_mask"] = amask.to(DEVICE)

            gen = model.generate(**gen_kwargs)
            dec = tokenizer.batch_decode(gen, skip_special_tokens=True)

            lbl = b["labels"].clone()
            lbl[lbl == -100] = tokenizer.pad_token_id
            ref = tokenizer.batch_decode(lbl, skip_special_tokens=True)

            preds.extend(dec)
            refs.extend(ref)

    wer = 100 * wer_metric.compute(predictions=preds, references=refs)
    cer = 100 * cer_metric.compute(predictions=preds, references=refs)
    ser = 100 * sum(p.strip()!=r.strip() for p,r in zip(preds,refs)) / len(refs)
    
    print(f"评估完成: {'增强' if augment else '原始'} {lang} 数据")
    print(f"  WER={wer:.2f}%, CER={cer:.2f}%, SER={ser:.2f}%")
    return wer, cer, ser

# ========== 主流程 ==========
if __name__ == "__main__":
    all_results = []
    print("\n===== 开始主评估流程 =====")
    
    # 对每个 checkpoint 依次评估
    for ckpt_idx, ckpt_path in enumerate(CHECKPOINT_PATHS):
        print(f"\n======= 评估模型 {ckpt_idx+1}/{len(CHECKPOINT_PATHS)} =======")
        print(f"模型路径: {ckpt_path}")
        
        # 1) 加载模型权重
        print(f"加载基础模型: {MODEL_NAME}...")
        model = WhisperForConditionalGeneration.from_pretrained(MODEL_NAME)
        print(f"加载检查点权重: {ckpt_path}...")
        checkpoint = torch.load(ckpt_path, map_location="cpu")
        model.load_state_dict(checkpoint['model_state'], strict=False)
        model.to(DEVICE).eval()
        print(f"模型加载完成, 转移到 {DEVICE}")

        # 2) 分别在原始 & 增强数据上评估
        for aug_flag, loaders in [ 
            (False, zero_loaders), 
            (True,  zero_loaders_aug) 
        ]:
            print(f"\n评估 {'增强' if aug_flag else '原始'} 数据")
            for lang_idx, (lang, loader) in enumerate(loaders.items()):
                print(f"\n处理语言 {lang_idx+1}/{len(loaders)}: {lang}")
                wer, cer, ser = eval_loader(loader, lang, aug_flag)
                all_results.append({
                    "checkpoint": os.path.basename(ckpt_path),
                    "language":  lang,
                    "Augment":   aug_flag,
                    "WER":       wer,
                    "CER":       cer,
                    "SER":       ser
                })

    # 3) 保存到 CSV
    print("\n===== 保存结果 =====")
    os.makedirs("results", exist_ok=True)
    out_df = pd.DataFrame(all_results)
    out_path = os.path.join("results", "zeroshot_with_augment_metrics.csv")
    out_df.to_csv(out_path, index=False)
    print(f"结果已保存至: {out_path}")
    print("\n===== 评估完成 =====")


'''import os
import torch
import random
import numpy as np
import pandas as pd
import evaluate
from datasets import Dataset, Audio
from transformers import (
    WhisperForConditionalGeneration,
    WhisperProcessor,
    WhisperTokenizer
)
from torch.utils.data import DataLoader
import logging
import warnings

# ========== 设置 & 路径 ==========
CHECKPOINT_PATH = ["whisper_partial_finetune_all3/best.pt","whisper_partial_finetune_denl/best.pt","whisper_partial_finetune_ende/best.pt","whisper_partial_finetune_ennl/best.pt"]

MODEL_NAME      = "openai/whisper-medium"
DEVICE          = "cuda" if torch.cuda.is_available() else "cpu"
BATCH_SIZE      = 16
SEED            = 42

# ========== 随机种子 ==========
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)

# ========== 忽略警告 ==========
warnings.filterwarnings("ignore", category=UserWarning)

# ========== 加载 Processor & Tokenizer ==========
processor = WhisperProcessor.from_pretrained(MODEL_NAME, task="transcribe")
tokenizer = WhisperTokenizer.from_pretrained(MODEL_NAME, task="transcribe")

# ========== 加载 模型 & 恢复权重 ==========
model = WhisperForConditionalGeneration.from_pretrained(MODEL_NAME)
checkpoint = torch.load(CHECKPOINT_PATH, map_location="cpu")
model.load_state_dict(checkpoint['model_state'], strict=False)
model.to(DEVICE)
model.eval()

# ========== 自定义 Dataset Class & Collator ==========
def spec_augment(feats, time_mask_param=30, freq_mask_param=13, num_time_masks=2, num_freq_masks=2):
    T, D = feats.shape
    for _ in range(num_time_masks):
        t = random.randint(0, time_mask_param)
        t0 = random.randint(0, max(0, T - t))
        feats[t0:t0+t, :] = 0
    for _ in range(num_freq_masks):
        f = random.randint(0, freq_mask_param)
        f0 = random.randint(0, max(0, D - f))
        feats[:, f0:f0+f] = 0
    return feats

class DynamicWhisperDataset(torch.utils.data.Dataset):
    def __init__(self, df, processor, tokenizer):
        self.df = df
        self.processor = processor
        self.tokenizer = tokenizer

    def __len__(self):
        return len(self.df)

    def __getitem__(self, i):
        item = self.df[i]
        audio = item["audio_path"]["array"]
        sr    = item["audio_path"]["sampling_rate"]
        feats = self.processor(audio, sampling_rate=sr, return_tensors="pt").input_features[0]

        # 构造 labels
        lang_tok = self.tokenizer.convert_tokens_to_ids(f"<|{item['language_name']}|>")
        label_ids = self.tokenizer(item["sentence"], return_tensors="pt", add_special_tokens=False).input_ids[0]
        prefix = [
            self.tokenizer.convert_tokens_to_ids("<|startoftranscript|>"),
            lang_tok,
            self.tokenizer.convert_tokens_to_ids("<|transcribe|>"),
            self.tokenizer.convert_tokens_to_ids("<|notimestamps|>")
        ]
        labels = torch.tensor(prefix + label_ids.tolist() + [self.tokenizer.eos_token_id])
        return {
            "input_features": feats,
            "attention_mask": torch.ones(feats.shape[-1]),
            "labels": labels,
            "language_name": item["language_name"]
        }

class WhisperDataCollator:
    def __init__(self, tok): self.tok = tok
    def __call__(self, batch):
        feats = torch.stack([x["input_features"] for x in batch])
        am    = torch.stack([x["attention_mask"]   for x in batch])
        labs  = [x["labels"] for x in batch]
        langs = [x["language_name"] for x in batch]

        max_len = max(l.size(0) for l in labs)
        pad_tokens = torch.full((len(batch), max_len), self.tok.pad_token_id)
        dec_mask   = torch.zeros((len(batch), max_len), dtype=torch.long)
        for i, l in enumerate(labs):
            pad_tokens[i, :l.size(0)] = l
            dec_mask[i, :l.size(0)]   = 1
        pad_tokens[pad_tokens == self.tok.pad_token_id] = -100

        return {
            "input_features": feats,
            "attention_mask": am,
            "labels": pad_tokens,
            "decoder_attention_mask": dec_mask,
            "language_name": langs
        }

collator = WhisperDataCollator(tokenizer)

# ========== Zero-Shot 数据集准备 ==========
zero_langs = ['af','fr', 'ja', 'ru', 'tr', 'zh-CN']
ZERO_MAP = {
    'fr': 'french', 
    'fy-NL': 'frisian', 
    'ja': 'japanese',
    'ru': 'russian', 
    'tr': 'turkish', 
    'zh-CN': 'mandarin',
    'af': 'afrikaans',
}
zero_datasets = {}
for zl in zero_langs:
    tsv_path = os.path.join('data/zero_shot', zl, 'validated.tsv')
    clips_dir = os.path.join('data/zero_shot', zl, 'clips')
    if not os.path.exists(tsv_path):
        logging.warning(f"Zero-shot missing {tsv_path}, skip")
        continue
    df = pd.read_csv(tsv_path, sep='\t')
    df = df[df['sentence'].notnull() & df['path'].notnull()]
    df['audio_path'] = df['path'].apply(lambda p: os.path.join(clips_dir, p))
    df = df[df['audio_path'].apply(os.path.exists)]
    df['language_name'] = ZERO_MAP[zl]
    ds = Dataset.from_pandas(df[['audio_path','sentence','language_name']])
    ds = ds.cast_column("audio_path", Audio(sampling_rate=16000))
    zero_datasets[ZERO_MAP[zl]] = ds

# 将 Zero-Shot 转为 DataLoader
zero_loaders = {}
for lang, ds in zero_datasets.items():
    dataset = DynamicWhisperDataset(ds, processor, tokenizer)
    zero_loaders[lang] = DataLoader(dataset,
                                    batch_size=BATCH_SIZE,
                                    shuffle=False,
                                    collate_fn=collator)

# ========== 评估函数 ==========
def eval_loader(loader):
    wer_metric = evaluate.load("wer")
    cer_metric = evaluate.load("cer")
    preds, refs, langs = [], [], []

    with torch.no_grad():
        for b in loader:
            feats = b["input_features"].to(DEVICE)
            amask = b.get("attention_mask", None)
            if amask is not None:
                amask = amask.to(DEVICE)
                gen = model.generate(
                    input_features=feats,
                    attention_mask=amask,
                    forced_decoder_ids=[
                        processor.get_decoder_prompt_ids(language=lang, task="transcribe")
                        for lang in b["language_name"]
                    ],
                    max_length=448,
                    num_beams=1
                )
            else:
                gen = model.generate(
                    input_features=feats,
                    forced_decoder_ids=[
                        processor.get_decoder_prompt_ids(language=lang, task="transcribe")
                        for lang in b["language_name"]
                    ],
                    max_length=448,
                    num_beams=1
                )

            dec = tokenizer.batch_decode(gen, skip_special_tokens=True)
            lbl = b["labels"].clone()
            lbl[lbl == -100] = tokenizer.pad_token_id
            ref = tokenizer.batch_decode(lbl, skip_special_tokens=True)

            preds.extend(dec)
            refs.extend(ref)
            langs.extend(b["language_name"])

    # 1) WER, CER
    wer_all = 100 * wer_metric.compute(predictions=preds, references=refs)
    cer_all = 100 * cer_metric.compute(predictions=preds, references=refs)

    # 2) SER（修正：只 * 100 一次）
    n_sent_errors = sum(p.strip() != r.strip() for p, r in zip(preds, refs))
    total_sent    = len(refs)
    ser_all       = (n_sent_errors / total_sent) * 100

    results = {"overall": (wer_all, cer_all, ser_all)}

    # 按语言细分
    for lang in set(langs):
        idxs    = [i for i, l in enumerate(langs) if l == lang]
        p_lang  = [preds[i] for i in idxs]
        r_lang  = [refs[i] for i in idxs]
        wer_l   = 100 * wer_metric.compute(predictions=p_lang, references=r_lang)
        cer_l   = 100 * cer_metric.compute(predictions=p_lang, references=r_lang)
        n_err_l = sum(p.strip() != r.strip() for p, r in zip(p_lang, r_lang))
        ser_l   = (n_err_l / len(r_lang)) * 100
        results[lang] = (wer_l, cer_l, ser_l)

    return results

# ========== 主流程 ==========
if __name__ == "__main__":
    final = []
    for lang, loader in zero_loaders.items():
        wer, cer, ser = eval_loader(loader)['overall']
        print(f"Zero-shot {lang}: WER={wer:.2f}%, CER={cer:.2f}%, SER={ser:.2f}%")
        final.append({
            "language": lang,
            "WER": wer,
            "CER": cer,
            "SER": ser
        })

    # 保存到 CSV
    df = pd.DataFrame(final)
    os.makedirs("results", exist_ok=True)
    out_path = os.path.join("results", "zeroshot_metrics.csv")
    df.to_csv(out_path, index=False)
    print(f"Results saved to {out_path}")
'''