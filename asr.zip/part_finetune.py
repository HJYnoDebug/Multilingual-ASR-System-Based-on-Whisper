import os
import logging
import time
import datetime
import itertools
import torch
import random
import numpy as np
import pandas as pd
import warnings
from datasets import Dataset, DatasetDict, concatenate_datasets, Audio
from transformers import (
    WhisperForConditionalGeneration,
    WhisperProcessor,
    WhisperTokenizer,
    get_linear_schedule_with_warmup
)
from torch.utils.data import DataLoader
from tqdm import tqdm
import evaluate
import torch.optim as optim
from torch.cuda.amp import GradScaler, autocast

# ========== 统一随机种子，保证可复现 ==========
seed = 42
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(seed)

# 忽略 torchvision 的警告
warnings.filterwarnings("ignore", category=UserWarning, message="Failed to load image Python extension")

# ========== 配置 Logging ==========
output_dir = "./whisper_partial_finetune"
os.makedirs(output_dir, exist_ok=True)
log_path = os.path.join(output_dir, "log.txt")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    handlers=[
        logging.FileHandler(log_path, mode='w', encoding='utf-8'),
        logging.StreamHandler()  # 同时输出到控制台
    ]
)

# ========== 1. 数据准备 ==========
#train_langs = ['de', 'en', 'nl']
train_langs = ['nl', 'de']
train_base = 'data/train'

#train_langs = ['de', 'en']
#train_base = 'data1/train'

TRAIN_MAP = {'de': 'german', 'en': 'english', 'nl': 'dutch'}

splits = {'train': [], 'validation': [], 'test': []}
for lang in train_langs:
    df_path = os.path.join(train_base, lang, 'validated.tsv')
    clips_dir = os.path.join(train_base, lang, 'clips')
    if not os.path.exists(df_path):
        logging.warning(f"Train: missing {df_path}, skip")
        continue

    df = pd.read_csv(df_path, sep='\t')
    df = df[df['sentence'].notnull() & df['path'].notnull()]
    df['audio_path'] = df['path'].apply(lambda p: os.path.join(clips_dir, p))
    df = df[df['audio_path'].apply(os.path.exists)]
    df['language_name'] = TRAIN_MAP[lang]
    if len(df) < 10:
        logging.info(f"Train: skipping {lang}, too few samples")
        continue

    ds = Dataset.from_pandas(df[['audio_path','sentence','language_name']])
    s1 = ds.train_test_split(test_size=0.1, seed=seed)
    s2 = s1['train'].train_test_split(test_size=0.1, seed=seed)
    splits['train'].append(s2['train'])
    splits['validation'].append(s2['test'])
    splits['test'].append(s1['test'])

train_val_test = DatasetDict({
    'train': concatenate_datasets(splits['train']),
    'validation': concatenate_datasets(splits['validation']),
    'test': concatenate_datasets(splits['test']),
})
train_val_test = train_val_test.cast_column("audio_path", Audio(sampling_rate=16000))

zero_langs = ['fr', 'ja', 'ru', 'tr', 'zh-CN']
zero_base = 'data/zero_shot'

#zero_langs = ['ja', 'ru', 'tr']
#zero_base = 'data1/zero_shot'

ZERO_MAP = {
    'fr': 'french',
    'ja': 'japanese',
    'ru': 'russian', 
    'tr': 'turkish', 
    'zh-CN': 'mandarin'
}
zero_datasets = {}
for zl in zero_langs:
    dfp = os.path.join(zero_base, zl, 'validated.tsv')
    clips = os.path.join(zero_base, zl, 'clips')
    if not os.path.exists(dfp):
        logging.warning(f"Zero-shot: missing {dfp}, skip")
        continue

    df = pd.read_csv(dfp, sep='\t')
    df = df[df['sentence'].notnull() & df['path'].notnull()]
    df['audio_path'] = df['path'].apply(lambda p: os.path.join(clips, p))
    df = df[df['audio_path'].apply(os.path.exists)]
    df['language_name'] = ZERO_MAP[zl]
    zero_datasets[ZERO_MAP[zl]] = Dataset.from_pandas(
        df[['audio_path','sentence','language_name']]
    ).cast_column("audio_path", Audio(sampling_rate=16000))

# ========== 2. 模型和处理器 ==========
model_name = "openai/whisper-medium"
processor = WhisperProcessor.from_pretrained(model_name, task="transcribe")
tokenizer = WhisperTokenizer.from_pretrained(model_name, task="transcribe")

# ========== 3. SpecAugment ==========
def spec_augment(feats, time_mask_param=30, freq_mask_param=13, num_time_masks=2, num_freq_masks=2):
    T, D = feats.shape
    for _ in range(num_time_masks):
        t = random.randint(0, time_mask_param)
        t0 = random.randint(0, max(0, T - t))
        feats[t0:t0+t, :] = 0
    for _ in range(num_freq_masks):
        f = random.randint(0, freq_mask_param)
        f0 = random.randint(0, max(0, D - f))
        feats[:, f0:f0+f] = 0
    return feats

# ========== 4. 自定义 Dataset ==========
class DynamicWhisperDataset(torch.utils.data.Dataset):
    def __init__(self, ds, processor, tokenizer, augment=False):
        self.ds = ds
        self.processor = processor
        self.tokenizer = tokenizer
        self.augment = augment
    def __len__(self):
        return len(self.ds)
    def __getitem__(self, i):
        item = self.ds[i]
        audio = item["audio_path"]["array"]
        sr = item["audio_path"]["sampling_rate"]
        feats = self.processor(audio, sampling_rate=sr, return_tensors="pt").input_features[0]
        if self.augment:
            feats = spec_augment(feats)
        lang_tok = self.tokenizer.convert_tokens_to_ids(f"<|{item['language_name']}|>")
        label_ids = self.tokenizer(item["sentence"], return_tensors="pt", add_special_tokens=False).input_ids[0]
        prefix = [
            self.tokenizer.convert_tokens_to_ids("<|startoftranscript|>"),
            lang_tok,
            self.tokenizer.convert_tokens_to_ids("<|transcribe|>"),
            self.tokenizer.convert_tokens_to_ids("<|notimestamps|>")
        ]
        labels = torch.tensor(prefix + label_ids.tolist() + [self.tokenizer.eos_token_id])
        return {
            "input_features": feats,
            "attention_mask": torch.ones(feats.shape[-1]),
            "labels": labels,
            "language_name": item["language_name"]
        }

train_ds = DynamicWhisperDataset(train_val_test["train"], processor, tokenizer, augment=True)
valid_ds = DynamicWhisperDataset(train_val_test["validation"], processor, tokenizer, augment=False)
test_ds  = DynamicWhisperDataset(train_val_test["test"], processor, tokenizer, augment=False)
zero_ds   = {lang: DynamicWhisperDataset(ds, processor, tokenizer, augment=False)
             for lang, ds in zero_datasets.items()}

# ========== 5. 冻结 & 统计参数 ==========
model = WhisperForConditionalGeneration.from_pretrained(model_name, device_map="auto")
model.config.use_cache = False

num_enc = model.config.encoder_layers
freeze_enc = int(num_enc * 0.75)
for i, layer in enumerate(model.model.encoder.layers):
    for p in layer.parameters():
        p.requires_grad = False if i < freeze_enc else True
for layer in model.model.decoder.layers:
    for p in layer.parameters():
        p.requires_grad = True
for n, p in model.named_parameters():
    if n.startswith("model.encoder.embed_tokens") or n.startswith("model.encoder.embed_positions") or "layer_norm" in n or n.startswith("lm_head"):
        p.requires_grad = True

total = sum(p.numel() for p in model.parameters())
trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
logging.info(f"Total params: {total:,} | Trainable: {trainable:,} ({100*trainable/total:.1f}%)")

# ========== 6. DataCollator ==========
class WhisperDataCollator:
    def __init__(self, tok): self.tok = tok
    def __call__(self, batch):
        feats = torch.stack([x["input_features"] for x in batch])
        am   = torch.stack([x["attention_mask"]   for x in batch])
        labs = [x["labels"] for x in batch]
        langs= [x["language_name"] for x in batch]
        ml = max(len(l) for l in labs)
        pad = torch.full((len(batch), ml), self.tok.pad_token_id)
        dm  = torch.zeros((len(batch), ml), dtype=torch.long)
        for i, l in enumerate(labs):
            pad[i,:len(l)] = l
            dm[i,:len(l)] = 1
        pad[pad==self.tok.pad_token_id] = -100
        return {
            "input_features": feats,
            "attention_mask": am,
            "labels": pad,
            "decoder_attention_mask": dm,
            "language_name": langs
        }

collator = WhisperDataCollator(tokenizer)

# ========== 7. 训练 参数 & 调度 ==========
batch_size = 16
grad_acc = 4
lr = 2e-5
wd = 0.01
warmup = 500
epochs = 5
eval_steps = 500
patience = 3
fp16 = True

train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, collate_fn=collator)
valid_loader = DataLoader(valid_ds, batch_size=batch_size, shuffle=False, collate_fn=collator)
test_loader  = DataLoader(test_ds, batch_size=batch_size, shuffle=False, collate_fn=collator)
zero_loaders = {lang: DataLoader(ds, batch_size=batch_size, shuffle=False, collate_fn=collator)
                for lang, ds in zero_ds.items()}

optim_ = optim.AdamW(filter(lambda p: p.requires_grad, model.parameters()), lr=lr, weight_decay=wd)
steps_per_epoch = len(train_loader) // grad_acc
total_steps = steps_per_epoch * epochs
sched = get_linear_schedule_with_warmup(optim_, num_warmup_steps=warmup, num_training_steps=total_steps)
scaler = GradScaler(enabled=fp16)

# ========== 8. 训练循环（含验证、早停、模型保存） ==========
model.train()
start_time = time.time()
global_step = 0
best_avg_wer = float('inf')  # 改为监控WER的MACRO平均
no_imp = 0
for ep in range(1, epochs + 1):
    logging.info(f"===== Epoch {ep}/{epochs} =====")
    epoch_losses = []
    for batch in tqdm(train_loader, desc="Training", leave=False):
        feats = batch["input_features"].to(model.device)
        am    = batch["attention_mask"].to(model.device)
        labs  = batch["labels"].to(model.device)
        with autocast(enabled=fp16):
            loss = model(input_features=feats, attention_mask=am, labels=labs).loss / grad_acc
        scaler.scale(loss).backward()

        if (global_step + 1) % grad_acc == 0:
            scaler.unscale_(optim_)
            torch.nn.utils.clip_grad_norm_(filter(lambda p: p.requires_grad, model.parameters()), 1.0)
            scaler.step(optim_)
            scaler.update()
            optim_.zero_grad()
            sched.step()

        epoch_losses.append(loss.item() * grad_acc)
        global_step += 1

        if global_step % eval_steps == 0:
            elapsed = time.time() - start_time
            remaining = elapsed / global_step * (total_steps - global_step)
            eta = str(datetime.timedelta(seconds=int(remaining)))
            recent = epoch_losses[-(eval_steps * grad_acc):]
            train_recent = np.mean(recent) if recent else float('nan')
            logging.info(f"Step {global_step}/{total_steps}, ETA: {eta}, Recent train loss={train_recent:.4f}")
            model.eval()
            quick_vals = []
            with torch.no_grad():
                for vb in itertools.islice(valid_loader, 2):
                    f = vb["input_features"].to(model.device)
                    m = vb["attention_mask"].to(model.device)
                    l = vb["labels"].to(model.device)
                    quick_vals.append(model(input_features=f, attention_mask=m, labels=l).loss.item())
            logging.info(f"Quick valid loss (2 batches)={np.mean(quick_vals):.4f}")
            model.train()

    # 训练 & 验证完整统计
    train_loss = np.mean(epoch_losses)
    logging.info(f"Epoch {ep} train loss = {train_loss:.4f}")
    model.eval()
    val_losses = []
    with torch.no_grad():
        for vb in tqdm(valid_loader, desc="Validating", leave=False):
            f = vb["input_features"].to(model.device)
            m = vb["attention_mask"].to(model.device)
            l = vb["labels"].to(model.device)
            val_losses.append(model(input_features=f, attention_mask=m, labels=l).loss.item())
    avg_val = np.mean(val_losses)
    logging.info(f"Epoch {ep} valid loss = {avg_val:.4f}")
    
    # ========== 新增：每个epoch后计算验证集的WER/CER/SER（按语言） ==========
    wer_metric = evaluate.load("wer")
    cer_metric = evaluate.load("cer")
    all_preds = {lang: [] for lang in train_langs}
    all_refs = {lang: [] for lang in train_langs}
    
    with torch.no_grad():
        for batch in tqdm(valid_loader, desc="Evaluating Validation", leave=False):
            feats = batch["input_features"].to(model.device)
            langs = batch["language_name"]
            forced_ids = [processor.get_decoder_prompt_ids(language=lang, task="transcribe") for lang in langs]
            gen = model.generate(input_features=feats, forced_decoder_ids=forced_ids, max_length=448, num_beams=1)
            dec = tokenizer.batch_decode(gen, skip_special_tokens=True)
            lbl = batch["labels"].clone()
            lbl[lbl == -100] = tokenizer.pad_token_id
            ref = tokenizer.batch_decode(lbl, skip_special_tokens=True)
            
            for i, lang in enumerate(langs):
                lang_key = [k for k, v in TRAIN_MAP.items() if v == lang][0]
                all_preds[lang_key].append(dec[i])
                all_refs[lang_key].append(ref[i])
    
    # 计算并记录每个语言的指标
    lang_metrics = {}
    for lang in train_langs:
        if len(all_preds[lang]) > 0:
            wer = 100 * wer_metric.compute(predictions=all_preds[lang], references=all_refs[lang])
            cer = 100 * cer_metric.compute(predictions=all_preds[lang], references=all_refs[lang])
            ser = 100 * sum(1 for p, r in zip(all_preds[lang], all_refs[lang]) if p.strip() != r.strip()) / len(all_refs[lang])
            lang_metrics[lang] = (wer, cer, ser)
            logging.info(f"Validation: {lang} => WER={wer:.2f}%, CER={cer:.2f}%, SER={ser:.2f}%")
    
    # 计算WER的MACRO平均（所有语言等权重）
    if lang_metrics:
        macro_avg_wer = np.mean([metrics[0] for metrics in lang_metrics.values()])
        logging.info(f"Validation MACRO AVG WER = {macro_avg_wer:.2f}%")
        
        # ========== 使用WER的MACRO平均进行早停 ==========
        if macro_avg_wer < best_avg_wer:
            best_avg_wer = macro_avg_wer
            no_imp = 0
            torch.save({
                'model_state': model.state_dict(),
                'optim_state': optim_.state_dict(),
                'sched_state': sched.state_dict(),
                'epoch': ep
            }, os.path.join(output_dir, "best.pt"))
            logging.info("Saved new best model")
        else:
            no_imp += 1
            if no_imp >= patience:
                logging.info("Early stopping triggered.")
                break
    else:
        logging.warning("No validation metrics computed")
    
    model.train()

# ========== 9. 评估函数 ==========
def eval_loader(loader, lang_map=None):
    wer_metric = evaluate.load("wer")
    cer_metric = evaluate.load("cer")
    all_preds = {}
    all_refs = {}
    
    with torch.no_grad():
        for batch in tqdm(loader, desc="Evaluating", leave=False):
            feats = batch["input_features"].to(model.device)
            langs = batch["language_name"]
            forced_ids = [processor.get_decoder_prompt_ids(language=lang, task="transcribe") for lang in langs]
            gen = model.generate(input_features=feats, forced_decoder_ids=forced_ids, max_length=448, num_beams=1)
            dec = tokenizer.batch_decode(gen, skip_special_tokens=True)
            lbl = batch["labels"].clone()
            lbl[lbl == -100] = tokenizer.pad_token_id
            ref = tokenizer.batch_decode(lbl, skip_special_tokens=True)
            
            for i, lang in enumerate(langs):
                # 如果是zeroshot语言，使用原始语言名
                lang_key = lang
                if lang_map:  # 对于in-domain测试，转换为语言代码
                    lang_key = [k for k, v in lang_map.items() if v == lang][0]
                
                if lang_key not in all_preds:
                    all_preds[lang_key] = []
                    all_refs[lang_key] = []
                
                all_preds[lang_key].append(dec[i])
                all_refs[lang_key].append(ref[i])
    
    metrics = {}
    for lang in all_preds.keys():
        wer = 100 * wer_metric.compute(predictions=all_preds[lang], references=all_refs[lang])
        cer = 100 * cer_metric.compute(predictions=all_preds[lang], references=all_refs[lang])
        ser = 100 * sum(1 for p, r in zip(all_preds[lang], all_refs[lang]) if p.strip() != r.strip()) / len(all_refs[lang])
        metrics[lang] = (wer, cer, ser)
    return metrics

# 加载最佳模型
checkpoint = torch.load(os.path.join(output_dir, "best.pt"))
model.load_state_dict(checkpoint['model_state'])
model.eval()

# in-domain 测试
test_metrics = eval_loader(test_loader, TRAIN_MAP)
for lang, (wer, cer, ser) in test_metrics.items():
    logging.info(f"Test: {lang} => WER={wer:.2f}%, CER={cer:.2f}%, SER={ser:.2f}%")

# zero-shot 测试
for lang, zl in zero_loaders.items():
    metrics = eval_loader(zl)
    for lang_name, (wer, cer, ser) in metrics.items():
        logging.info(f"zero_shot {lang_name} => WER={wer:.2f}%, CER={cer:.2f}%, SER={ser:.2f}%")